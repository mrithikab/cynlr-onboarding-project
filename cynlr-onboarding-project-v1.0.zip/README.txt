﻿# Cynlr Onboarding Project - Release Package

## Directory Structure

    cynlr-onboarding-project.exe    Main application
    TestRunner.exe                  Runs all tests
    test.csv                        Sample CSV input
    tests/unit/                     Unit test executables
    tests/integration/              Integration test executables

## Quick Start

1. Extract all files maintaining the directory structure
2. Run all tests: TestRunner.exe
3. Run main app: cynlr-onboarding-project.exe --mode=csv --csv=test.csv --threshold=100 --T_ns=1000

## Running the Main Application

CSV Mode:
    cynlr-onboarding-project.exe --mode=csv --csv=test.csv --threshold=100 --T_ns=1000

Random Mode (interactive, press Enter to stop):
    cynlr-onboarding-project.exe --mode=random --threshold=100 --T_ns=1000 --columns=1024

With Statistics (creates pair_metrics.csv):
    cynlr-onboarding-project.exe --mode=csv --csv=test.csv --threshold=100 --T_ns=1000 --stats

Quiet Mode (for scripting):
    cynlr-onboarding-project.exe --mode=csv --csv=test.csv --threshold=100 --T_ns=1000 --quiet

Custom Filter Kernel:
    cynlr-onboarding-project.exe --mode=csv --csv=test.csv --threshold=100 --T_ns=1000 --filter=file --filterfile=my_kernel.txt

## Running Tests

Run all tests:
    TestRunner.exe

Run individual unit tests:
    tests\unit\TestCsvStreamer.exe
    tests\unit\TestFilterBlock.exe
    tests\unit\TestFilterBlockCalc.exe
    tests\unit\TestDataGenerator.exe

Run individual integration tests:
    tests\integration\IntegrationTestDataGenerator.exe
    tests\integration\TestCli.exe

## Command-Line Options

    --mode=random|csv          Input mode (random generation or CSV file)
    --threshold=<number>       Filter threshold value (TV)
    --T_ns=<uint64>           Inter-pair timing in nanoseconds (>=500)
    --columns=<int>           Number of columns (auto-detected for CSV mode)
    --filter=default|file     Use default kernel or load from file
    --stats                   Enable CSV statistics output (pair_metrics.csv)
    --csv=<path>              CSV input file path (required for csv mode)
    --filterfile=<path>       Custom 9-tap filter kernel file
    --quiet                   Suppress all output except errors
    --help                    Display usage information

## Creating Custom CSV Input

Create a CSV file with comma-separated integer values (0-255).
Example: 10,20,30,40,50,60

The application will auto-detect columns, process values in pairs,
clamp to 0-255 range, and skip malformed values with warnings.

## Creating Custom Filter Kernels

Create a text file with 9 space-separated decimal numbers.
Example: 0.1 0.2 0.3 0.4 0.5 0.4 0.3 0.2 0.1

The filter is non-causal:
  - kernel[0] multiplies with oldest sample (most past)
  - kernel[4] multiplies with center (current) sample
  - kernel[8] multiplies with newest (future) sample

## Notes

- Tests create temporary files that are cleaned up automatically
- When using --stats, pair_metrics.csv is created in current directory
- Pipeline prints statistics unless --quiet is specified
- All executables must remain in this directory structure

## Troubleshooting

Executable not found error in tests:
  - Ensure files were extracted maintaining directory structure
  - Set CYNLR_EXE environment variable to cynlr-onboarding-project.exe path

Failed to read CSV error:
  - Check CSV file exists and is readable
  - Verify CSV contains numeric values separated by commas
  - Ensure at least 2 values (one pair) present

Tests fail with path errors:
  - Run TestRunner.exe from release package root directory
  - Do not move executables between directories

## Version Information

Build Configuration: Release x64
Build Date: 2026-01-18 19:32:56
Source: https://github.com/mrithikab/cynlr-onboarding-project

